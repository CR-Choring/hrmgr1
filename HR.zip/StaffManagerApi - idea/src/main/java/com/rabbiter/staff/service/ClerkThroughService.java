package com.rabbiter.staff.service;

import com.rabbiter.staff.entity.ClerkThrough;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 员工经历表 服务类
 * </p>
 *
 * @author
 * @since 2024-03-14
 */
public interface ClerkThroughService extends IService<ClerkThrough> {

}
